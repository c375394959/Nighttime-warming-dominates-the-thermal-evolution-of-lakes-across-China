import pandas as pd
import numpy as np
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from statsmodels.nonparametric.smoothers_lowess import lowess

# ---------------------------------------------------------

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman"],
    "font.size": 16,
    "axes.labelsize": 18,
    "axes.titlesize": 18,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "legend.fontsize": 16,
    'axes.unicode_minus': False
})

# 1. Load Data
df = pd.read_excel(r"Data of the random forest (during the day).xlsx")
features = ['Daytime cloud cover', 'Daytime longwave radiation', 'Daytime precipitation',
            'Daytime shortwave radiation', 'Daytime temperature', 'Daytime wind speed']
target = 'Daytime LSWT'

# df = pd.read_excel(r"Data of the random forest (during the night).xlsx")
# features = ['Nighttime cloud cover', 'Nighttime longwave radiation', 'Nighttime precipitation',
#             'Nighttime shortwave radiation', 'Nighttime temperature', 'Nighttime wind speed']
# target = 'Nighttime LSWT'

X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 2. Hyperparameter Optimization
xgb_model = xgb.XGBRegressor(objective='reg:squarederror', random_state=42, n_jobs=-1)

param_grid = {
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.05],
    'n_estimators': [500, 1000],
    'subsample': [0.7, 0.8],
    'colsample_bytree': [0.7, 0.8],
    'min_child_weight': [1, 3],
    'gamma': [0, 0.1]
}

grid_search = GridSearchCV(estimator=xgb_model, param_grid=param_grid,
                           cv=5, n_jobs=-1, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_

# 3. Model Accuracy Evaluation
y_pred = best_model.predict(X_test)
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

print("-" * 30)
print("Model Accuracy Evaluation Results:")
print(f"Best Parameters: {grid_search.best_params_}")
print(f"R²: {r2:.4f} | MAE: {mae:.4f} | RMSE: {rmse:.4f} | MAPE: {mape:.4f}%")
print("-" * 30)

# Accuracy Scatter Plot
plt.figure(figsize=(7, 7))
plt.scatter(y_test, y_pred, alpha=0.5, color='blue', edgecolors='k')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel('Measured Daytime LSWT', fontsize=18)
plt.ylabel('Predicted Daytime LSWT', fontsize=18)
plt.title(f'Accuracy Check (R² = {r2:.3f})', fontsize=20)
plt.tight_layout()
plt.savefig('Model_Accuracy_Check.png', dpi=500)
plt.show()

# 4. Calculate SHAP values
explainer = shap.TreeExplainer(best_model)
shap_values_all = explainer.shap_values(X_test)

# 5. Plot: Dependency Plots with Smoothed Trend Line (Large font version)
for i, col in enumerate(features):
    fig, ax = plt.subplots(figsize=(7, 6))

    # Generate SHAP dependence plot
    shap.dependence_plot(col, shap_values_all, X_test,
                         interaction_index=None,
                         ax=ax,
                         show=False,
                         alpha=0.4)

    # Extract data and apply LOWESS smoothing
    x_data = X_test[col].values
    y_data = shap_values_all[:, i]
    smoothed = lowess(y_data, x_data, frac=0.3)
    ax.plot(smoothed[:, 0], smoothed[:, 1], color='red', lw=3, label='Trend')

    # Enforce axis font styles
    ax.set_xlabel(col, fontsize=18, fontfamily='serif')
    ax.set_ylabel('SHAP value', fontsize=18, fontfamily='serif')
    ax.tick_params(labelsize=16)  # Slightly smaller ticks for better proportions
    ax.grid(True, linestyle='--', alpha=0.3)

    plt.tight_layout()
    plt.savefig(f'Shap_Smooth_{col}.png', dpi=500)
    plt.show()

# 6. Generate Summary Plots (Large font version)
# Beeswarm Plot
plt.figure(figsize=(12, 8))
shap.summary_plot(shap_values_all, X_test, show=False)
plt.gca().set_xlabel('SHAP value (impact on model output)', fontsize=18)
# Adjust feature name font sizes on the y-axis
plt.gca().tick_params(axis='y', labelsize=16)
plt.gca().tick_params(axis='x', labelsize=16)
plt.tight_layout()
plt.savefig('Summary_Beeswarm.png', dpi=500)
plt.close()

# Bar Plot
plt.figure(figsize=(12, 8))
shap.summary_plot(shap_values_all, X_test, plot_type="bar", show=False)
plt.gca().set_xlabel('mean(|SHAP value|)', fontsize=18)
plt.gca().tick_params(axis='y', labelsize=16)
plt.gca().tick_params(axis='x', labelsize=16)
plt.tight_layout()
plt.savefig('Summary_Bar.png', dpi=500)
plt.close()

print("All charts have been saved with large fonts (16-18pt).")